package tr.autoschematic;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.util.Identifier;
import tr.autoschematic.core.Features;

public class AutoSchematicMod implements ClientModInitializer {
    public static final String ID = "autoschematic";

    @Override
    public void onInitializeClient() {
        Features.init();
        ClientTickEvents.END_CLIENT_TICK.register(Features::tick);
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, Identifier.of(ID, "hud"),
                (ctx, tickCounter) -> Features.hud(ctx, tickCounter.getTickProgress(false)));
    }
}
