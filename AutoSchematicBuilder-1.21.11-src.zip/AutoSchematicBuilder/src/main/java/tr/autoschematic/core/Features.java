package tr.autoschematic.core;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;
import tr.autoschematic.Look;
import tr.autoschematic.Util;
import tr.autoschematic.gui.ClickGui;
import tr.autoschematic.gui.Hud;
import tr.autoschematic.modules.auto.AreaMiner;
import tr.autoschematic.modules.auto.AutoEat;
import tr.autoschematic.modules.auto.AutoReplenish;
import tr.autoschematic.modules.auto.MissingItem;
import tr.autoschematic.modules.auto.SchematicBuilder;
import tr.autoschematic.modules.auto.SpawnerDetect;
import tr.autoschematic.modules.combat.AutoArmor;
import tr.autoschematic.modules.combat.AutoTotem;
import tr.autoschematic.modules.combat.InvTotem;
import tr.autoschematic.modules.combat.KillAura;
import tr.autoschematic.modules.misc.AutoLog;
import tr.autoschematic.modules.misc.AutoRespawn;
import tr.autoschematic.modules.misc.AutoSprint;
import tr.autoschematic.modules.misc.GuiFeature;
import tr.autoschematic.modules.misc.PlayerDetect;
import tr.autoschematic.modules.misc.StaffList;
import tr.autoschematic.modules.visual.Atmosphere;
import tr.autoschematic.modules.visual.BetterItem;
import tr.autoschematic.modules.visual.CustomFov;
import tr.autoschematic.modules.visual.FreeLook;
import tr.autoschematic.modules.visual.Fullbright;
import tr.autoschematic.modules.visual.HandAura;
import tr.autoschematic.modules.visual.HandView;
import tr.autoschematic.modules.visual.HudInfo;
import tr.autoschematic.modules.visual.SlowHand;
import tr.autoschematic.modules.visual.Zoom;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Modül kaydı, config (JSON), tuş dinleme, tick ve HUD dağıtımı. */
public final class Features {
    private Features() {
    }

    public static final List<Feature> ALL = new ArrayList<>();

    public static AutoTotem AUTO_TOTEM;
    public static InvTotem INV_TOTEM;
    public static AutoArmor AUTO_ARMOR;
    public static KillAura KILL_AURA;
    public static HudInfo HUD_INFO;
    public static Fullbright FULLBRIGHT;
    public static Zoom ZOOM;
    public static HandView HAND_VIEW;
    public static SlowHand SLOW_HAND;
    public static Atmosphere ATMOSPHERE;
    public static BetterItem BETTER_ITEM;
    public static HandAura HAND_AURA;
    public static CustomFov CUSTOM_FOV;
    public static FreeLook FREE_LOOK;
    public static AreaMiner AREA_MINER;
    public static SpawnerDetect SPAWNER;
    public static SchematicBuilder BUILDER;
    public static MissingItem MISSING;
    public static AutoEat AUTO_EAT;
    public static AutoReplenish AUTO_REPLENISH;
    public static PlayerDetect PLAYER_DETECT;
    public static AutoLog AUTO_LOG;
    public static AutoRespawn AUTO_RESPAWN;
    public static AutoSprint AUTO_SPRINT;
    public static StaffList STAFF;
    public static GuiFeature GUI;

    // ---------------------------------------------------------------- config

    public static final class State {
        public boolean enabled;
        public int key = -1;
        public boolean hold;
        public Map<String, String> s = new LinkedHashMap<>();
    }

    public static final class Data {
        public Map<String, State> features = new LinkedHashMap<>();
        public List<String> staffKeywords = new ArrayList<>(Arrays.asList(
                "owner", "founder", "kurucu", "sahip", "admin", "sradmin", "sr", "srmod",
                "mod", "moderator", "moderatör", "helper", "yetkili", "yönetici", "sorumlu",
                "destek", "support", "dev", "developer", "manager", "trainee"));
        public List<String> staffNames = new ArrayList<>();
    }

    public static Data data = new Data();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("autoschematic.json");
    }

    private static <T extends Feature> T reg(T f) {
        ALL.add(f);
        return f;
    }

    public static void init() {
        AUTO_TOTEM = reg(new AutoTotem());
        INV_TOTEM = reg(new InvTotem());
        AUTO_ARMOR = reg(new AutoArmor());
        KILL_AURA = reg(new KillAura());

        HUD_INFO = reg(new HudInfo());
        FULLBRIGHT = reg(new Fullbright());
        ZOOM = reg(new Zoom());
        HAND_VIEW = reg(new HandView());
        SLOW_HAND = reg(new SlowHand());
        ATMOSPHERE = reg(new Atmosphere());
        BETTER_ITEM = reg(new BetterItem());
        HAND_AURA = reg(new HandAura());
        CUSTOM_FOV = reg(new CustomFov());
        FREE_LOOK = reg(new FreeLook());

        AREA_MINER = reg(new AreaMiner());
        SPAWNER = reg(new SpawnerDetect());
        BUILDER = reg(new SchematicBuilder());
        MISSING = reg(new MissingItem());
        AUTO_EAT = reg(new AutoEat());
        AUTO_REPLENISH = reg(new AutoReplenish());

        PLAYER_DETECT = reg(new PlayerDetect());
        AUTO_LOG = reg(new AutoLog());
        AUTO_RESPAWN = reg(new AutoRespawn());
        AUTO_SPRINT = reg(new AutoSprint());
        STAFF = reg(new StaffList());

        GUI = reg(new GuiFeature());
        load();
    }

    public static List<Feature> of(Category c) {
        List<Feature> out = new ArrayList<>();
        for (Feature f : ALL) {
            if (f.cat == c) out.add(f);
        }
        return out;
    }

    private static void load() {
        try {
            Path f = file();
            if (Files.exists(f)) {
                Data d = GSON.fromJson(Files.readString(f), Data.class);
                if (d != null) data = d;
            }
        } catch (Exception e) {
            System.err.println("[AutoSchematic] ayar okunamadi: " + e);
        }
        if (data.features == null) data.features = new LinkedHashMap<>();
        if (data.staffKeywords == null) data.staffKeywords = new ArrayList<>();
        if (data.staffNames == null) data.staffNames = new ArrayList<>();

        for (Feature f : ALL) {
            State st = data.features.get(f.name);
            if (st == null) continue;
            if (f.toggleable()) f.enabled = st.enabled;
            f.key = st.key;
            f.hold = st.hold;
            for (Setting s : f.settings) {
                if (!s.persist() || st.s == null) continue;
                String v = st.s.get(s.name);
                if (v != null) s.load(v);
            }
        }
        if (GUI.key <= 0) GUI.key = GLFW.GLFW_KEY_RIGHT_SHIFT;
        save();
    }

    public static void save() {
        for (Feature f : ALL) {
            State st = new State();
            st.enabled = f.enabled;
            st.key = f.key;
            st.hold = f.hold;
            for (Setting s : f.settings) {
                if (s.persist()) st.s.put(s.name, s.save());
            }
            data.features.put(f.name, st);
        }
        try {
            Files.writeString(file(), GSON.toJson(data));
        } catch (Exception e) {
            System.err.println("[AutoSchematic] ayar yazilamadi: " + e);
        }
    }

    // ---------------------------------------------------------------- tick / hud

    public static void tick(MinecraftClient mc) {
        long handle = mc.getWindow().getHandle();
        boolean free = mc.currentScreen == null;

        for (Feature f : ALL) {
            boolean raw = f.key > 0 && GLFW.glfwGetKey(handle, f.key) == GLFW.GLFW_PRESS;
            boolean down = raw && free;
            if (f.key > 0) {
                if (f == GUI) {
                    if (down && !f.wasDown && mc.player != null) mc.setScreen(new ClickGui());
                } else if (f.hold) {
                    if (down && !f.enabled) f.setEnabled(true);
                    else if (!raw && f.wasDown && f.enabled) f.setEnabled(false);
                } else if (down && !f.wasDown) {
                    f.toggle();
                }
            }
            f.wasDown = raw;
        }

        if (mc.player == null || mc.world == null) {
            Look.active = false;
            return;
        }
        Look.tick(mc);

        for (Feature f : ALL) {
            if (!f.enabled || !f.toggleable()) continue;
            try {
                f.onTick(mc);
            } catch (Throwable t) {
                fail(mc, f, t);
            }
        }
    }

    public static void hud(DrawContext ctx, float tickProgress) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
        Hud.begin();
        for (Feature f : ALL) {
            if (!f.enabled || !f.toggleable()) continue;
            try {
                f.onHud(ctx, mc, tickProgress);
            } catch (Throwable t) {
                fail(mc, f, t);
            }
        }
    }

    /** Bir modül hata verirse oyunu çökertmek yerine o modülü kapatır. */
    private static void fail(MinecraftClient mc, Feature f, Throwable t) {
        f.enabled = false;
        System.err.println("[AutoSchematic] " + f.name + " hata verdi ve kapatildi: " + t);
        t.printStackTrace();
        Util.info(mc, f.name + " hata verdi, kapatıldı: " + t.getClass().getSimpleName());
    }
}
