package tr.autoschematic.core;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import tr.autoschematic.Util;

import java.util.ArrayList;
import java.util.List;

/** Tüm modüllerin tabanı: ad, kategori, aç/kapa, tuş ataması ve ayar listesi. */
public abstract class Feature {
    public final String name;
    public final String desc;
    public final Category cat;
    public boolean enabled;
    public int key = -1;           // GLFW tuş kodu, -1 = atanmamış
    public boolean hold;           // true: tuşa basılı tutarken açık
    public final List<Setting> settings = new ArrayList<>();
    public float anim;             // GUI açma/kapama animasyonu
    public boolean wasDown;        // tuş kenar algılama (Features kullanır)

    protected Feature(String name, String desc, Category cat) {
        this.name = name;
        this.desc = desc;
        this.cat = cat;
    }

    protected <T extends Setting> T add(T s) {
        settings.add(s);
        return s;
    }

    /** GUI'deki aç/kapa düğmesi gösterilsin mi? */
    public boolean toggleable() {
        return true;
    }

    public void setEnabled(boolean on) {
        if (on == enabled) return;
        enabled = on;
        if (on) onEnable();
        else onDisable();
    }

    public void toggle() {
        setEnabled(!enabled);
        Util.info(MinecraftClient.getInstance(), name + ": " + (enabled ? "AÇIK" : "KAPALI"));
    }

    public void onEnable() {
    }

    public void onDisable() {
    }

    public void onTick(MinecraftClient mc) {
    }

    public void onHud(DrawContext ctx, MinecraftClient mc, float tickProgress) {
    }
}
