package tr.autoschematic.core;

public enum Category {
    COMBAT("COMBAT"),
    VISUALS("VISUALS"),
    AUTO("AUTO"),
    MISC("MISC"),
    THEME("THEME");

    public final String label;

    Category(String label) {
        this.label = label;
    }
}
