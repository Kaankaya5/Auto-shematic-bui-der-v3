package tr.autoschematic.mixin;

import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import tr.autoschematic.modules.visual.VisualFx;

/** Dünya FOV'u (Custom FOV) ve el FOV'u (Hand Aura) için GameRenderer.getFov dönüş değerini değiştirir. */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true, require = 0)
    private void autoschematic$fov(Camera camera, float tickProgress, boolean changingFov,
                                   CallbackInfoReturnable<Float> cir) {
        Float v = VisualFx.fov(cir.getReturnValue(), changingFov);
        if (v != null) cir.setReturnValue(v);
    }
}
