package tr.autoschematic;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;
import tr.autoschematic.core.Features;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Tab listesindeki (oyuncu listesi) öneklerden yetkili/rank sahiplerini bulur.
 * Sadece istemcinin zaten bildiği bilgiyi okur; sunucuya bir şey göndermez.
 */
public final class Staff {
    private Staff() {
    }

    public static final class Entry {
        public final String name;
        public final String rank;
        public final Text shown;

        Entry(String name, String rank, Text shown) {
            this.name = name;
            this.rank = rank;
            this.shown = shown;
        }
    }

    public static volatile List<Entry> list = new ArrayList<>();
    private static final Pattern SPLIT = Pattern.compile("[^\\p{L}\\p{N}]+");

    public static void refresh(MinecraftClient mc, boolean anyRank) {
        ClientPlayNetworkHandler h = mc.getNetworkHandler();
        if (h == null) {
            list = new ArrayList<>();
            return;
        }
        Set<String> keys = new HashSet<>();
        for (String k : Features.data.staffKeywords) keys.add(k.toLowerCase(Locale.ROOT));
        Set<String> names = new HashSet<>();
        for (String n : Features.data.staffNames) names.add(n.toLowerCase(Locale.ROOT));

        PlayerListHud hud = mc.inGameHud.getPlayerListHud();
        List<Entry> out = new ArrayList<>();
        for (PlayerListEntry e : h.getPlayerList()) {
            String name = Util.profileName(e.getProfile());
            Text shown = hud.getPlayerName(e);
            String plain = shown.getString();

            int idx = name.isEmpty() ? -1 : plain.indexOf(name);
            String around = idx >= 0 ? plain.substring(0, idx) + " " + plain.substring(idx + name.length()) : plain;
            String prefix = idx > 0 ? plain.substring(0, idx).trim() : "";

            String rank = "";
            for (String tok : SPLIT.split(around.toLowerCase(Locale.ROOT))) {
                if (!tok.isEmpty() && keys.contains(tok)) {
                    rank = tok;
                    break;
                }
            }
            boolean byName = names.contains(name.toLowerCase(Locale.ROOT));
            if (!rank.isEmpty() || byName || (anyRank && !prefix.isEmpty())) {
                if (rank.isEmpty()) rank = prefix.isEmpty() ? "liste" : prefix;
                out.add(new Entry(name, rank, shown));
            }
        }
        out.sort(Comparator.comparing((Entry en) -> en.name.toLowerCase(Locale.ROOT)));
        list = out;
    }
}
