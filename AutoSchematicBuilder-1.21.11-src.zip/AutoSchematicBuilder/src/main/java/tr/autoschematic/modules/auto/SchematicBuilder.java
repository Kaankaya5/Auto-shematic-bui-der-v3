package tr.autoschematic.modules.auto;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import tr.autoschematic.Litema;
import tr.autoschematic.Planner;
import tr.autoschematic.Util;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Setting;
import tr.autoschematic.gui.Hud;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Litematica şematiğini algılar ve menzildeki eksik blokları sırayla yerleştirir.
 * Az paket: varsayılan 3 tickte 1 blok (Gecikme ve Blok/tur ayarlarıyla değiştirilir).
 */
public final class SchematicBuilder extends Feature {
    public final Setting.Num range = add(new Setting.Num("Menzil", 4, 1, 6, 1));
    public final Setting.Num delay = add(new Setting.Num("Gecikme (tick)", 3, 0, 20, 1));
    public final Setting.Num perTick = add(new Setting.Num("Blok/tur", 1, 1, 4, 1));
    public final Setting.Mode order = add(new Setting.Mode("Sıra", "Yakından uzağa", "Alttan üste"));
    public final Setting.Bool refill = add(new Setting.Bool("Envanterden hotbar'a çek", true));
    public final Setting.Num refillSlot = add(new Setting.Num("Çekilecek hotbar slotu", 9, 1, 9, 1));
    public final Setting.Bool pauseLow = add(new Setting.Bool("Can düşükse dur", true));
    public final Setting.Num pauseHealth = add(new Setting.Num("Dur (can <=)", 6, 1, 20, 1));
    public final Setting.Bool showHud = add(new Setting.Bool("Durumu ekrana yaz", true));

    public String status = "Kapalı";
    public int placedTotal;
    public int nearby;
    /** Son turda envanterde bulunamayan malzemeler (item -> kaç blok eksik). */
    public final Map<Item, Integer> missing = new LinkedHashMap<>();

    private int cooldown;
    private int tickNo;
    private final Map<Long, Integer> skipUntil = new HashMap<>();

    public SchematicBuilder() {
        super("Auto Schematic Builder",
                "Litematica şematiğini algılar, menzildeki eksik blokları az paketle yerleştirir.",
                Category.AUTO);
    }

    @Override
    public void onDisable() {
        status = "Kapalı";
        missing.clear();
    }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc, float tickProgress) {
        if (showHud.v) {
            Hud.left(ctx, mc, "Builder: " + status + "  |  yerleşen " + placedTotal, 0xFF9AA0AE);
        }
    }

    public Item topMissing() {
        Item best = null;
        int bestN = -1;
        for (Map.Entry<Item, Integer> e : missing.entrySet()) {
            if (e.getValue() > bestN) {
                best = e.getKey();
                bestN = e.getValue();
            }
        }
        return best;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        tickNo++;
        if (tickNo % 400 == 0) skipUntil.values().removeIf(v -> v < tickNo);

        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        ClientPlayerInteractionManager im = mc.interactionManager;
        if (p == null || w == null || im == null) return;

        if (!Litema.present()) {
            status = "Litematica bulunamadı";
            return;
        }
        World sw = Litema.schematicWorld();
        if (sw == null) {
            status = "Şematik yok";
            return;
        }
        if (mc.currentScreen != null) {
            status = "Bekliyor (menü açık)";
            return;
        }
        if (p.isSpectator()) {
            status = "Spectator";
            return;
        }
        if (pauseLow.v && p.getHealth() + p.getAbsorptionAmount() <= pauseHealth.v) {
            status = "Duraklatıldı: can düşük";
            return;
        }
        if (cooldown > 0) {
            cooldown--;
            return;
        }
        cooldown = delay.i();

        double reach = Math.min(range.v, p.getBlockInteractionRange());
        int r = (int) Math.ceil(reach);
        BlockPos base = p.getBlockPos();
        Vec3d eye = p.getEyePos();
        double lim = (reach + 1.0) * (reach + 1.0);

        List<BlockPos> cands = new ArrayList<>();
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    BlockPos pos = base.add(dx, dy, dz);
                    if (eye.squaredDistanceTo(Vec3d.ofCenter(pos)) > lim) continue;
                    BlockState want = sw.getBlockState(pos);
                    if (want.isAir()) continue;
                    BlockState have = w.getBlockState(pos);
                    if (have == want) continue;
                    if (!have.isAir() && !have.isReplaceable()) continue;
                    Integer until = skipUntil.get(pos.asLong());
                    if (until != null && until > tickNo) continue;
                    cands.add(pos);
                }
            }
        }
        nearby = cands.size();

        Comparator<BlockPos> byDist =
                Comparator.comparingDouble((BlockPos b) -> eye.squaredDistanceTo(Vec3d.ofCenter(b)));
        Comparator<BlockPos> cmp = order.idx == 1
                ? Comparator.comparingInt((BlockPos b) -> b.getY()).thenComparing(byDist)
                : byDist;
        cands.sort(cmp);

        missing.clear();
        int placed = 0;
        for (BlockPos pos : cands) {
            if (placed >= perTick.i()) break;
            BlockState want = sw.getBlockState(pos);
            Item item = want.getBlock().asItem();
            if (item == Items.AIR) {
                skipUntil.put(pos.asLong(), tickNo + 600);
                continue;
            }

            int slot = findSlot(p, item, !refill.v);
            if (slot < 0) {
                missing.merge(item, 1, Integer::sum);
                continue;
            }
            if (slot >= 9) {
                if (p.currentScreenHandler != p.playerScreenHandler) continue;
                int hb = Math.max(0, Math.min(8, refillSlot.i() - 1));
                im.clickSlot(p.playerScreenHandler.syncId, Util.screenSlot(slot), hb, SlotActionType.SWAP, p);
                slot = hb;
            }

            ItemStack stack = p.getInventory().getStack(slot);
            Planner.Plan plan = Planner.plan(w, p, pos, want, stack, reach);
            if (plan == null) {
                skipUntil.put(pos.asLong(), tickNo + 100);
                continue;
            }

            place(mc, p, im, slot, plan);
            skipUntil.put(pos.asLong(), tickNo + 20);   // sunucu reddederse 1 sn sonra tekrar dene
            placed++;
            placedTotal++;
        }

        if (placed > 0) {
            status = "Çalışıyor";
        } else if (!missing.isEmpty()) {
            Item top = topMissing();
            status = "Malzeme eksik: " + (top == null ? "?" : top.getName().getString());
        } else if (cands.isEmpty()) {
            status = "Menzilde eksik blok yok";
        } else {
            status = "Yerleştirilemeyen blok: " + cands.size();
        }
    }

    private static void place(MinecraftClient mc, ClientPlayerEntity p, ClientPlayerInteractionManager im,
                              int slot, Planner.Plan plan) {
        PlayerInventory inv = p.getInventory();
        int prev = inv.getSelectedSlot();
        float oy = p.getYaw();
        float op = p.getPitch();

        inv.setSelectedSlot(slot);
        if (plan.rotate) {
            p.setYaw(plan.yaw);
            p.setPitch(plan.pitch);
            sendLook(mc, p, plan.yaw, plan.pitch);
        }

        BlockHitResult hit = new BlockHitResult(plan.hit, plan.face, plan.neighbor, false);
        ActionResult res = im.interactBlock(p, Hand.MAIN_HAND, hit);
        if (res.isAccepted()) {
            p.swingHand(Hand.MAIN_HAND);
        }

        if (plan.rotate) {
            p.setYaw(oy);
            p.setPitch(op);
            sendLook(mc, p, oy, op);
        }
        inv.setSelectedSlot(prev);
    }

    private static void sendLook(MinecraftClient mc, ClientPlayerEntity p, float yaw, float pitch) {
        if (mc.getNetworkHandler() == null) return;
        mc.getNetworkHandler().sendPacket(
                new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch, p.isOnGround(), p.horizontalCollision));
    }

    private static int findSlot(ClientPlayerEntity p, Item item, boolean hotbarOnly) {
        int s = Util.findItem(p, item, 0, 9);
        if (s >= 0 || hotbarOnly) return s;
        return Util.findItem(p, item, 9, 36);
    }
}
