package tr.autoschematic.modules.combat;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;
import tr.autoschematic.Util;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Setting;

/** Envanterdeki en iyi zırh parçalarını (netherite > elmas > demir...) otomatik giyer. */
public final class AutoArmor extends Feature {
    private static final String[] PIECE = {"_helmet", "_chestplate", "_leggings", "_boots"};
    private static final String[] TIER = {"leather", "gold", "chainmail", "iron", "diamond", "netherite"};

    private final Setting.Num delay = add(new Setting.Num("Gecikme (tick)", 4, 1, 20, 1));
    private int wait;
    private int tickNo;
    private final int[] retryAt = new int[4];

    public AutoArmor() {
        super("Auto Armor", "Envanterdeki daha iyi zırh parçalarını otomatik giyer.", Category.COMBAT);
    }

    /** Parça türüne uyuyorsa kalite sırası (0..5), uymuyorsa -2. */
    private static int tier(ItemStack s, int piece) {
        if (s.isEmpty()) return -2;
        String id = Registries.ITEM.getId(s.getItem()).getPath();
        if (!id.endsWith(PIECE[piece])) return -2;
        for (int i = TIER.length - 1; i >= 0; i--) {
            if (id.startsWith(TIER[i])) return i;
        }
        return -1;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        tickNo++;
        ClientPlayerEntity p = mc.player;
        ClientPlayerInteractionManager im = mc.interactionManager;
        if (p == null || im == null) return;
        if (p.currentScreenHandler != p.playerScreenHandler) return;
        if (!p.playerScreenHandler.getCursorStack().isEmpty()) return;
        if (wait > 0) {
            wait--;
            return;
        }
        int sync = p.playerScreenHandler.syncId;

        for (int piece = 0; piece < 4; piece++) {
            if (tickNo < retryAt[piece]) continue;
            int armorSlot = 5 + piece;
            ItemStack worn = p.playerScreenHandler.getSlot(armorSlot).getStack();
            int wornScore;
            if (worn.isEmpty()) wornScore = -1;
            else {
                int t = tier(worn, piece);
                wornScore = t == -2 ? Integer.MAX_VALUE : t;   // elytra vb. tanınmayan parçaya dokunma
            }

            int best = -1;
            int bestScore = wornScore;
            for (int i = 0; i < 36; i++) {
                int sc = tier(p.getInventory().getStack(i), piece);
                if (sc > bestScore) {
                    bestScore = sc;
                    best = i;
                }
            }
            if (best < 0) continue;

            if (!worn.isEmpty()) {
                im.clickSlot(sync, armorSlot, 0, SlotActionType.QUICK_MOVE, p);   // eskisini envantere gönder
            } else {
                im.clickSlot(sync, Util.screenSlot(best), 0, SlotActionType.QUICK_MOVE, p);   // yenisini giy
            }
            retryAt[piece] = tickNo + 30;   // bağlanma laneti vb. durumda sürekli denemesin
            wait = delay.i();
            return;
        }
    }
}
