package tr.autoschematic.modules.misc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;

/** İleri tuşuna basarken sürekli koşar (açlık yeterliyse). */
public final class AutoSprint extends Feature {
    public AutoSprint() {
        super("Auto Sprint", "İleri giderken otomatik koşar.", Category.MISC);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.currentScreen != null) return;
        if (mc.options.forwardKey.isPressed() && !p.isSneaking() && !p.horizontalCollision
                && p.getHungerManager().getFoodLevel() > 6) {
            p.setSprinting(true);
        }
    }
}
