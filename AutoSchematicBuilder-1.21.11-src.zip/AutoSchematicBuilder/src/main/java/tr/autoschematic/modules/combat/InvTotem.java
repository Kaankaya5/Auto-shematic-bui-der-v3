package tr.autoschematic.modules.combat;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import tr.autoschematic.Util;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Setting;

/** Sadece envanter ekranı AÇIKKEN çalışır: offhand'i ve istersen bir hotbar slotunu totemle doldurur. */
public final class InvTotem extends Feature {
    private final Setting.Num delay = add(new Setting.Num("Gecikme (tick)", 2, 0, 10, 1));
    private final Setting.Num spare = add(new Setting.Num("Yedek totem slotu (0=kapalı)", 0, 0, 9, 1));
    private int wait;

    public InvTotem() {
        super("Auto Inv Totem", "Envanter açıkken offhand'e (ve istersen bir hotbar slotuna) totem yerleştirir.",
                Category.COMBAT);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (!(mc.currentScreen instanceof InventoryScreen)) return;
        ClientPlayerEntity p = mc.player;
        ClientPlayerInteractionManager im = mc.interactionManager;
        if (p == null || im == null) return;
        if (p.currentScreenHandler != p.playerScreenHandler) return;
        if (!p.playerScreenHandler.getCursorStack().isEmpty()) return;
        if (wait > 0) {
            wait--;
            return;
        }
        int sync = p.playerScreenHandler.syncId;

        if (!p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
            int found = Util.findItem(p, Items.TOTEM_OF_UNDYING, 0, 36);
            if (found >= 0) {
                im.clickSlot(sync, Util.screenSlot(found), 40, SlotActionType.SWAP, p);
                wait = delay.i();
                return;
            }
        }

        int hs = spare.i();
        if (hs > 0) {
            int hb = hs - 1;
            if (!p.getInventory().getStack(hb).isOf(Items.TOTEM_OF_UNDYING)) {
                int src = Util.findItem(p, Items.TOTEM_OF_UNDYING, 9, 36);
                if (src >= 0) {
                    im.clickSlot(sync, Util.screenSlot(src), hb, SlotActionType.SWAP, p);
                    wait = delay.i();
                }
            }
        }
    }
}
