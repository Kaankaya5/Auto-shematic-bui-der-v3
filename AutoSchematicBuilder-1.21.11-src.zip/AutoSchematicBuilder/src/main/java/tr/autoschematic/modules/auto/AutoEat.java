package tr.autoschematic.modules.auto;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Setting;

import java.util.List;

/** Açlık eşiğin altına düşünce hotbar'daki en iyi yemeği otomatik yer. */
public final class AutoEat extends Feature {
    private static final List<String> FOODS = List.of(
            "cooked_beef", "cooked_porkchop", "golden_carrot", "cooked_mutton", "cooked_salmon", "baked_potato",
            "bread", "cooked_chicken", "cooked_rabbit", "cooked_cod", "pumpkin_pie", "apple", "carrot",
            "melon_slice", "sweet_berries", "dried_kelp", "cookie");

    private final Setting.Num hunger = add(new Setting.Num("Açlık eşiği (<=)", 14, 1, 19, 1));
    private boolean eating;
    private int prevSlot = -1;

    public AutoEat() {
        super("Auto Eat", "Açlık düşünce hotbar'daki yemeği otomatik yer (kötü yemekleri yemez).", Category.AUTO);
    }

    @Override
    public void onDisable() {
        stop(MinecraftClient.getInstance());
    }

    private void stop(MinecraftClient mc) {
        if (mc == null) return;
        if (eating) mc.options.useKey.setPressed(false);
        if (prevSlot >= 0 && mc.player != null) mc.player.getInventory().setSelectedSlot(prevSlot);
        prevSlot = -1;
        eating = false;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        if (mc.currentScreen != null) {
            stop(mc);
            return;
        }
        if (eating) {
            if (!p.isUsingItem() && !p.getInventory().getStack(p.getInventory().getSelectedSlot()).isEmpty()
                    && p.getHungerManager().getFoodLevel() <= hunger.i() && prevSlot < 0) {
                eating = false;
            }
            if (p.isUsingItem()) {
                mc.options.useKey.setPressed(true);
            } else {
                stop(mc);
            }
            return;
        }
        if (p.getHungerManager().getFoodLevel() > hunger.i()) return;

        PlayerInventory inv = p.getInventory();
        int slot = -1;
        int rank = Integer.MAX_VALUE;
        for (int i = 0; i < 9; i++) {
            ItemStack s = inv.getStack(i);
            if (s.isEmpty()) continue;
            int r = FOODS.indexOf(Registries.ITEM.getId(s.getItem()).getPath());
            if (r >= 0 && r < rank) {
                rank = r;
                slot = i;
            }
        }
        if (slot < 0) return;

        prevSlot = inv.getSelectedSlot();
        inv.setSelectedSlot(slot);
        eating = true;
        mc.options.useKey.setPressed(true);
    }
}
