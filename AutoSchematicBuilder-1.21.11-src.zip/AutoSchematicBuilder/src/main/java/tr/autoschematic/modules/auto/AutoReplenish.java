package tr.autoschematic.modules.auto;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import tr.autoschematic.Util;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Setting;

/** Hotbar'daki bir yığın azalınca (örn. blok koyarken) envanterdeki aynı eşyadan tamamlar. */
public final class AutoReplenish extends Feature {
    private final Setting.Num threshold = add(new Setting.Num("Azalma eşiği (<=)", 8, 1, 32, 1));
    private final Setting.Num delay = add(new Setting.Num("Gecikme (tick)", 5, 1, 20, 1));
    private int wait;

    public AutoReplenish() {
        super("Auto Replenish", "Hotbar'daki yığın azalınca envanterdeki aynı eşyadan otomatik tamamlar.",
                Category.AUTO);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        ClientPlayerInteractionManager im = mc.interactionManager;
        if (p == null || im == null) return;
        if (p.currentScreenHandler != p.playerScreenHandler) return;
        if (!p.playerScreenHandler.getCursorStack().isEmpty()) return;
        if (wait > 0) {
            wait--;
            return;
        }
        PlayerInventory inv = p.getInventory();
        for (int hb = 0; hb < 9; hb++) {
            ItemStack st = inv.getStack(hb);
            if (st.isEmpty() || !st.isStackable()) continue;
            if (st.getCount() > threshold.i() || st.getCount() >= st.getMaxCount()) continue;
            for (int i = 9; i < 36; i++) {
                ItemStack o = inv.getStack(i);
                if (o.isEmpty() || !st.isOf(o.getItem())) continue;
                im.clickSlot(p.playerScreenHandler.syncId, Util.screenSlot(i), 0, SlotActionType.QUICK_MOVE, p);
                wait = delay.i();
                return;
            }
        }
    }
}
