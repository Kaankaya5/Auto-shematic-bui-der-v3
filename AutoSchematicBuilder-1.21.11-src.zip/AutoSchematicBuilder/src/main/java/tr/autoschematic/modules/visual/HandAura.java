package tr.autoschematic.modules.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Setting;

/**
 * El/eşya çevresinde renkli parıltı efekti (rengi GUI'den seçilir) ve ayrı bir el FOV'u (varsayılan 130).
 * Not: parıltı, ekrana çizilen yıldız efektidir; gerçek kenar parlaması (shader) değildir.
 */
public final class HandAura extends Feature {
    public final Setting.Color color = add(new Setting.Color("Parıltı rengi", 0x4FC3F7));
    public final Setting.Num density = add(new Setting.Num("Parıltı yoğunluğu", 8, 1, 20, 1));
    public final Setting.Bool handFov = add(new Setting.Bool("El FOV'u uygula", true));
    public final Setting.Num fov = add(new Setting.Num("El FOV", 130, 30, 170, 5));

    public HandAura() {
        super("Hand Aura", "El ve eşya çevresinde renkli parıltı. Ayrı bir el FOV'u da uygular (varsayılan 130).",
                Category.VISUALS);
    }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc, float tickProgress) {
        if (!mc.options.getPerspective().isFirstPerson()) return;
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        long t = System.currentTimeMillis();
        int n = density.i();
        for (int i = 0; i < n; i++) {
            long period = 700 + (i * 137L) % 500;
            long shifted = t + i * 311L;
            long phase = shifted % period;
            long cycle = shifted / period;
            float alpha = (float) Math.sin(phase / (float) period * Math.PI);
            long seed = cycle * 7919L + i * 104729L;
            double rx = ((seed * 31 + 7) % 1000) / 1000.0;
            double ry = ((seed * 17 + 3) % 1000) / 1000.0;
            int x = (int) (sw * (0.62 + 0.30 * rx));
            int y = (int) (sh * (0.62 + 0.30 * ry));
            int size = 1 + (int) (seed % 3);
            int a = (int) (alpha * 230);
            ctx.fill(x - size, y, x + size + 1, y + 1, color.argb(a));
            ctx.fill(x, y - size, x + 1, y + size + 1, color.argb(a));
            ctx.fill(x, y, x + 1, y + 1, 0xFFFFFFFF);
        }
    }
}
