package tr.autoschematic.modules.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Features;
import tr.autoschematic.core.Setting;
import tr.autoschematic.gui.Hud;
import tr.autoschematic.gui.Theme;

import java.util.ArrayList;
import java.util.List;

/** Ekran bilgileri: filigran, koordinat, FPS, zırh dayanıklılığı, totem sayısı ve açık modül listesi. */
public final class HudInfo extends Feature {
    private final Setting.Bool watermark = add(new Setting.Bool("Filigran", true));
    private final Setting.Bool coords = add(new Setting.Bool("Koordinat + yön", true));
    private final Setting.Bool fps = add(new Setting.Bool("FPS", true));
    private final Setting.Bool armor = add(new Setting.Bool("Zırh dayanıklılığı", true));
    private final Setting.Bool totems = add(new Setting.Bool("Totem sayısı", true));
    private final Setting.Bool list = add(new Setting.Bool("Açık modül listesi (sağ)", true));

    public HudInfo() {
        super("HUD", "Koordinat, FPS, zırh, totem sayısı ve açık modül listesini ekrana yazar.", Category.VISUALS);
        enabled = true;
    }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc, float tickProgress) {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        int accent = Theme.accent();

        if (watermark.v) Hud.left(ctx, mc, "Schematic Client", accent);
        if (coords.v) {
            Hud.left(ctx, mc, "XYZ " + p.getBlockX() + " " + p.getBlockY() + " " + p.getBlockZ()
                    + "  [" + p.getHorizontalFacing().name() + "]", 0xFFE0E0E0);
        }
        if (fps.v) Hud.left(ctx, mc, "FPS " + mc.getCurrentFps(), 0xFFE0E0E0);

        if (totems.v) {
            int n = 0;
            for (int i = 0; i < 36; i++) {
                ItemStack s = p.getInventory().getStack(i);
                if (s.isOf(Items.TOTEM_OF_UNDYING)) n += s.getCount();
            }
            ItemStack off = p.getOffHandStack();
            if (off.isOf(Items.TOTEM_OF_UNDYING)) n += off.getCount();
            Hud.left(ctx, mc, "Totem: " + n, n > 0 ? 0xFFE0E0E0 : 0xFFFF6B6B);
        }

        if (armor.v) {
            for (int slot = 5; slot <= 8; slot++) {
                ItemStack s = p.playerScreenHandler.getSlot(slot).getStack();
                if (s.isEmpty()) continue;
                int max = s.getMaxDamage();
                String d = max > 0 ? (max - s.getDamage()) + "/" + max : "";
                Hud.left(ctx, mc, s.getItem().getName().getString() + " " + d, 0xFFB8BDC9);
            }
        }

        if (list.v) {
            List<Feature> on = new ArrayList<>();
            for (Feature f : Features.ALL) {
                if (f.enabled && f.toggleable()) on.add(f);
            }
            on.sort((a, b) -> Integer.compare(mc.textRenderer.getWidth(b.name), mc.textRenderer.getWidth(a.name)));
            for (Feature f : on) Hud.right(ctx, mc, Text.literal(f.name), accent);
        }
    }
}
