package tr.autoschematic.modules.visual;

import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Setting;

/** Normal ayarlardaki sınırın dışında (daha düşük/yüksek) görüş açısı. Bağımsız modüldür. */
public final class CustomFov extends Feature {
    public final Setting.Num fov = add(new Setting.Num("FOV", 100, 10, 170, 1));

    public CustomFov() {
        super("Custom FOV", "Oyun ayarlarındaki sınırdan bağımsız görüş açısı (10-170).", Category.VISUALS);
    }
}
