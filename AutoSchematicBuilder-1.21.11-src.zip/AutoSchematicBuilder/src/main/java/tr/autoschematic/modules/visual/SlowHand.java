package tr.autoschematic.modules.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Setting;

/** El sallama animasyonunu yavaşlatır (sadece görsel; saldırı hızını değiştirmez). */
public final class SlowHand extends Feature {
    private final Setting.Num slow = add(new Setting.Num("Yavaşlık (kat)", 3, 2, 12, 1));
    private int c;

    public SlowHand() {
        super("Slow Hand", "El sallama animasyonunu yavaşlatır. Saldırı/kazma hızını etkilemez.", Category.VISUALS);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        if (p.handSwinging && p.handSwingTicks > 0) {
            // animasyon ilerlemesini (N-1)/N oranında geri al
            if (++c % slow.i() != 0) p.handSwingTicks--;
        } else {
            c = 0;
        }
    }
}
