package tr.autoschematic.modules.misc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.DeathScreen;
import tr.autoschematic.core.Category;
import tr.autoschematic.core.Feature;
import tr.autoschematic.core.Setting;

/** Ölünce ölüm ekranında bekletmeden yeniden doğar. */
public final class AutoRespawn extends Feature {
    private final Setting.Num delay = add(new Setting.Num("Bekleme (tick)", 10, 0, 100, 1));
    private int t;

    public AutoRespawn() {
        super("Auto Respawn", "Ölünce otomatik yeniden doğar.", Category.MISC);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.player != null && mc.currentScreen instanceof DeathScreen) {
            if (++t >= delay.i()) {
                mc.player.requestRespawn();
                t = 0;
            }
        } else {
            t = 0;
        }
    }
}
