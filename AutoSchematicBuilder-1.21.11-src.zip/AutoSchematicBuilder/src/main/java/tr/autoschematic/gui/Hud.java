package tr.autoschematic.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

/** Ekranın köşelerine alt alta bilgi satırı yazmak için basit yığın. */
public final class Hud {
    private Hud() {
    }

    private static int left;
    private static int right;

    public static void begin() {
        left = 4;
        right = 4;
    }

    public static void left(DrawContext c, MinecraftClient mc, String s, int color) {
        c.drawTextWithShadow(mc.textRenderer, Text.literal(s), 4, left, color);
        left += 10;
    }

    public static void right(DrawContext c, MinecraftClient mc, Text t, int color) {
        int w = mc.textRenderer.getWidth(t);
        c.drawTextWithShadow(mc.textRenderer, t, mc.getWindow().getScaledWidth() - w - 4, right, color);
        right += 10;
    }
}
