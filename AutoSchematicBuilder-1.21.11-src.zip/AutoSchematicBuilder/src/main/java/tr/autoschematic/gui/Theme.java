package tr.autoschematic.gui;

import tr.autoschematic.core.Features;

/** GUI renkleri. Vurgu rengi, opaklık ve köşe yuvarlaklığı "GUI" modülünden gelir. */
public final class Theme {
    private Theme() {
    }

    public static int accent() {
        return Features.GUI.accent.argb();
    }

    public static int accentA(int alpha) {
        return Features.GUI.accent.argb(alpha);
    }

    public static int bg() {
        return (Features.GUI.opacity.i() << 24) | 0x0D0D14;
    }

    public static int panel() {
        return (Math.min(255, Features.GUI.opacity.i() + 6) << 24) | 0x15151F;
    }

    public static int row() {
        return 0xFF1C1C27;
    }

    public static int rowHover() {
        return 0xFF262633;
    }

    public static int off() {
        return 0xFF3A3A4A;
    }

    public static int text() {
        return 0xFFEDEDF2;
    }

    public static int sub() {
        return 0xFF8E93A3;
    }

    public static int radius() {
        return Features.GUI.radius.i();
    }
}
