# Schematic Client — Fabric 1.21.11

Right Shift ile açılan menü (Combat / Visuals / Auto / Misc / Theme), her modüle ayrı tuş ataması ve tema ayarı.

## Oyunda gerekenler (mods klasörü)
Fabric Loader 0.18.1+, Fabric API (1.21.11), Litematica + MaLiLib (1.21.11). Litematica yalnızca şematik modülleri için gerekir.

## Menü
- **Right Shift**: menüyü aç/kapat (Theme > GUI > "Tuş" kutusundan değiştirilebilir).
- Soldan kategori, ortadan modül seç. Modül adının sağındaki anahtar = aç/kapa.
- Sağ panel: modülün ayarları. En üstte **Tuş** kutusu: tıkla, sonra istediğin tuşa bas (Delete/Backspace = sil, sağ tık = sil).
  Yanındaki düğme: **Aç/Kapa** (basınca değişir) ya da **Basılı tut** (tuşa basılıyken açık).
- Theme > GUI: hazır temalar, vurgu rengi seçici (H/S/B), arka plan opaklığı, köşe yuvarlaklığı.
- Ayarlar `config/autoschematic.json` dosyasına otomatik kaydedilir.

## Modüller
**Combat**
- Auto Totem: offhand'de totem yoksa envanterden koyar.
- Auto Inv Totem: envanter açıkken offhand'i (ve istersen bir hotbar slotunu) totemle doldurur.
- Auto Armor: envanterdeki daha iyi zırh parçalarını (netherite > elmas > demir...) otomatik giyer.
- Kill Aura: menzildeki düşman moblara otomatik vurur. Oyunculara vurmaz.

**Visuals**
- HUD: koordinat+yön, FPS, zırh dayanıklılığı, totem sayısı, filigran ve açık modül listesi.
- Fullbright: karanlıkta her yer aydınlık (sadece sende). Zoom: basılı tutarken yakınlaştırır.
- Hand View: el/eşya konum, boyut, açı. Slow Hand: el sallama animasyonunu yavaşlatır.
- Atmosphere: sadece sende görünen hava durumu / zaman. Custom FOV: ayarlardaki sınırdan bağımsız FOV (10-170).
- Better Item: eşya elin üstünde süzülür ve 360° döner.
- Hand Aura: el/eşya çevresinde renkli parıltı (renk GUI'den) + ayrı el FOV'u (varsayılan 130).
- Free Look: kamera oyuncudan bağımsız döner (tuşu "Basılı tut" yap).

**Auto**
- Auto Area Miner: menzildeki blokları sırayla kırar (yarıçap ya da Pos1-Pos2 kutusu). Yürümez.
- Auto Spawner Detect: yüklü chunk'lardaki tüm spawner'ları kırmızı çubuk + chunk çerçevesi + etiketle işaretler, uyarır.
- Auto Schematic Builder: Litematica şematiğini algılar, menzildeki eksik blokları az paketle yerleştirir (varsayılan 3 tickte 1 blok).
- Auto Missing Item: şematikte eksik eşyayı market komutuyla alır (komut şablonu ayarlardan).
- Auto Eat: açlık düşünce hotbar'daki yemeği yer. Auto Replenish: hotbar yığını azalınca envanterden tamamlar.

**Misc**
- Player Detect: yakınına oyuncu gelirse sunucudan çıkar; çıkış ekranında "Player Detect: nick" yazar ("Sadece uyar" seçeneği var).
- Staff List: tab listesindeki yetkili/rank'lıları köşede gösterir.
- Auto Log: can eşiğin altına düşerse sunucudan çıkar. Auto Respawn: ölünce otomatik doğar. Auto Sprint: ileri giderken koşar.

## GitHub'da derleme (kısa)
Ayrıntılı anlatım sohbette; özet:
1. Repoda `.github/workflows/build.yml` (bu projedeki build.yml) ve proje (zip ya da klasör olarak) bulunur.
2. Her commit'te **Actions** sekmesinde `build-jar` çalışır (3-6 dk).
3. Yeşil olunca **Releases** > en yeni build > `AutoSchematicBuilder-1.21.11.jar`.
4. Kırmızı olursa: çalışma > **Summary** içindeki "Derleme başarısız" kutusu ya da `build-log` dosyası.
5. Güncelleme: yeni zip'i **aynı adla** yükle (üzerine yazar).

## Notlar / sınırlar
- Hand Aura'daki parıltı ekrana çizilen yıldız efektidir; gerçek kenar parlaması (shader) değildir.
- Atmosphere'in zaman ayarı, 1.21.11'in yeni saat sisteminde etkisiz kalabilir; hava kısmı çalışır.
- Auto Area Miner ve Builder yürümez; sen alanda dolaşırsın.
- Bir modül hata verirse oyun çökmez, o modül kapanır ve ekranda haber verilir.
- Mixin'ler "required: false": bir mixin hedefi uymazsa sadece o görsel özellik çalışmaz, oyun açılır.
- Bu tür modlar birçok sunucunun kurallarında yasaktır; sorumluluk sende. Kod gizleme/şifreleme yoktur.
